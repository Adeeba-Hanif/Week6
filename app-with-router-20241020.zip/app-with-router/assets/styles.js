import {StyleSheet} from 'react-native';
const globleStyles= StyleSheet.create(
    {
        container :
        {


        },
        txt:
        {
            color:'yellow'
        }

    }

)

export default globleStyles;